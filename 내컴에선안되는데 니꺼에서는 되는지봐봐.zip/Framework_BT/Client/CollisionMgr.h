#pragma once
class CCollisionMgr
{
public:
	CCollisionMgr();
	~CCollisionMgr();

public:
	static void CollisionRect(OBJLIST& dstList, OBJLIST& srcList);
	static void CollisionSphere(OBJLIST& dstList, OBJLIST& srcList);

private:
	static bool CheckSphere(CObj* pDst, CObj* pSrc);
};

