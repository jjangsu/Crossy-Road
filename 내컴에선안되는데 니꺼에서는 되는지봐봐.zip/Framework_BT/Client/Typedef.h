#pragma once

class CObj;

typedef list<CObj*>			OBJLIST;
typedef OBJLIST::iterator	OBJITER;
