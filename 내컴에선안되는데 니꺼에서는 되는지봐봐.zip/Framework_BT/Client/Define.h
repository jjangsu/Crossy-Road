#pragma once

#define WINCX 800
#define WINCY 600
