#pragma once

extern HWND g_hWnd;
