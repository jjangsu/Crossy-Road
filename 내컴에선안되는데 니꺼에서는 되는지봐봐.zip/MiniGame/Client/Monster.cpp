#include "stdafx.h"
#include "Monster.h"
#include "Bullet.h"

CMonster::CMonster()
{
}


CMonster::~CMonster()
{
	Release();
}

void CMonster::Initialize()
{
	srand(unsigned(time(nullptr)));
	m_dwOldTime = GetTickCount();
}

int CMonster::Update()
{
	if (m_dwOldTime + 1500 < GetTickCount())
	{
		int iCount = (rand() % 20) + 10;

		for (int i = 0; i < iCount; ++i)
		{
			DIRECTION iDirection = DIRECTION(rand() % DIR_END);
			m_pBulletList->push_back(CreateBullet(iDirection));
		}

		m_dwOldTime = GetTickCount();
	}
	

	return 0;
}

void CMonster::Render(HDC hDC)
{
	
}

void CMonster::Release()
{
}


CObj* CMonster::CreateBullet()
{
	return CAbsractFactory<CBullet>::CreateObj(m_tInfo.fX, m_tInfo.fY);
}

CObj* CMonster::CreateBullet(DIRECTION eDir)
{
	float fX = 0.f, fY = 0.f;

	switch (eDir)
	{
	case DIR_UP:
	case DIR_LU:
	case DIR_RU:
		fX = rand() % WINCX;
		fY = 600.f;
		break;
	case DIR_DOWN:
	case DIR_LD:
	case DIR_RD:
		fX = rand() % WINCX;
		fY = 0.f;
		break;
	case DIR_LEFT:
		fX = 800.f;
		fY = rand() % WINCY;
		break;
	case DIR_RIGHT:
		fX = 0.f;
		fY = rand() % WINCY;
		break;
	}

	CObj* pBullet = CAbsractFactory<CBullet>::CreateObj(fX, fY);
	dynamic_cast<CBullet*>(pBullet)->SetDir(eDir);

	return pBullet;
}