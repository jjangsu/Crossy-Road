#pragma once
#include "Obj.h"
class CMonster :
	public CObj
{
public:
	CMonster();
	virtual ~CMonster();

public:
	void SetBulletList(OBJLIST* pBulletList) { m_pBulletList = pBulletList; }

public:
	// CObj��(��) ���� ��ӵ�
	virtual void Initialize() override;
	virtual int Update() override;
	virtual void Render(HDC hDC) override;
	virtual void Release() override;

private:
	CObj* CreateBullet();
	CObj* CreateBullet(DIRECTION eDir);

private:
	OBJLIST* m_pBulletList;
	DWORD	 m_dwOldTime;
};

